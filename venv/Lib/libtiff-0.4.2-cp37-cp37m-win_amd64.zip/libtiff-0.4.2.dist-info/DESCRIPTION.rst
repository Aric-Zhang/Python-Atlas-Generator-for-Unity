PyLibTiff? is a Python package that provides the following modules:

libtiff - a wrapper of C libtiff library using ctypes.
tiff - a numpy.memmap view of tiff files.


